## yObywatel 2.0

Uwaga! Ten projekt służy jedynie jako pamiątka kolekcjonerska.

https://morleee.github.io/yObywatel

### Instrukcja zainstalowania:
#### Dla systemu IOS:
- Upewnij się, że używasz przeglądarki Safari
- Uzupełnij dane i kliknij wejdź
- Naciśji udostępnij -> Do Ekranu głównego
#### Dla systemu Android:
- Upewnij się, że używasz przeglądarki google lub chrome
- Uzupełnij dane i kliknij wejdź
- Naciśji 3 kropki -> Dodaj do ekranu głównego

[Dołącz na naszego discorda](https://discord.gg/EDg7A8sWqm)
